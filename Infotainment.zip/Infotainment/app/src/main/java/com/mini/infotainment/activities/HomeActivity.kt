package com.mini.infotainment.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import com.mini.infotainment.R
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : Activity() {
    var txtTime: TextView? = null
    var txtDate: TextView? = null
    var c: Calendar? = null
    var simpleDateFormat: SimpleDateFormat? = null
    var simpleTimeFormat: SimpleDateFormat? = null
    var grdView: GridView? = null
    var containAppDrawer: LinearLayout? = null
    var containerHome: RelativeLayout? = null

    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_home)
        simpleDateFormat = SimpleDateFormat("dd-MMM-yyyy")
        simpleTimeFormat = SimpleDateFormat("hh:mm:ss.SSS a")
        txtTime = findViewById<View>(R.id.txtTime) as TextView
        txtDate = findViewById<View>(R.id.txtDate) as TextView
        containAppDrawer = findViewById<View>(R.id.containAppDrawer) as LinearLayout
        containerHome = findViewById<View>(R.id.ContainerHome) as RelativeLayout
        hideAppDrawer(false)

        val timer = Timer()
        timer.schedule(object : TimerTask() {
            override fun run() {
                runOnUiThread {
                    c = Calendar.getInstance()
                    txtDate!!.text = simpleDateFormat!!.format((c as Calendar).time)
                    txtTime!!.text = simpleTimeFormat!!.format((c as Calendar).time)
                }
            }
        }, 0, 10)

        apps = null
        adapter = null
        loadApps()
        loadListView()
        addGridListeners()
    }

    fun addGridListeners() {
        try {
            grdView!!.onItemClickListener =
                OnItemClickListener { _, _, i, _ ->
                    val intent =
                        packageManager!!.getLaunchIntentForPackage(apps!![i].name.toString())
                    this@HomeActivity.startActivity(intent)
                }
        } catch (ex: Exception) {}
    }

    private fun loadListView() {
        try {
            grdView = findViewById<View>(R.id.grd_allApps) as GridView
            if (adapter == null) {
                adapter = object : ArrayAdapter<AppInfo>(this, R.layout.grd_items, apps!!) {
                    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                        var convertView = convertView
                        var viewHolder: Any?

                        if (convertView == null) {
                            convertView = layoutInflater.inflate(R.layout.grd_items, parent, false)
                            viewHolder = ViewHolderItem()

                            viewHolder.icon = convertView!!.findViewById<View>(R.id.img_icon) as ImageView?
                            viewHolder.name = convertView.findViewById<View>(R.id.txt_name) as TextView?
                            viewHolder.label = convertView.findViewById<View>(R.id.txt_label) as TextView?
                            convertView.tag = viewHolder
                        } else {
                            viewHolder = convertView.tag as ViewHolderItem
                        }

                        val appInfo = apps!![position]
                        viewHolder.icon!!.setImageDrawable(appInfo.icon)
                        viewHolder.label!!.text = appInfo.label
                        viewHolder.name!!.text = appInfo.name

                        return convertView
                    }

                    inner class ViewHolderItem {
                        var icon: ImageView? = null
                        var label: TextView? = null
                        var name: TextView? = null
                    }
                }
            }
            grdView!!.adapter = adapter
        } catch (ex: Exception) {}
    }

    private fun loadApps() {
        try {
            if (apps == null) {
                apps = ArrayList()
                val i = Intent(Intent.ACTION_MAIN, null)
                i.addCategory(Intent.CATEGORY_LAUNCHER)
                val availableApps = packageManager!!.queryIntentActivities(i, 0)
                for (ri in availableApps) {
                    val appinfo = AppInfo()
                    appinfo.label = ri.loadLabel(packageManager)
                    appinfo.name = ri.activityInfo.packageName
                    appinfo.icon = ri.activityInfo.loadIcon(packageManager)
                    (apps as ArrayList<AppInfo>).add(appinfo)
                }
            }
        }catch (ex: Exception) {}
    }

    fun showApps(v: View?) {
        // Intent i = new Intent(HomeActivity.this, GetApps.class);
        //startActivity(i);
        hideAppDrawer(true)
    }

    fun hideAppDrawer(visibility: Boolean) {
        if (visibility) {
            containAppDrawer!!.visibility = View.VISIBLE
            containerHome!!.visibility = View.GONE
        } else {
            containAppDrawer!!.visibility = View.GONE
            containerHome!!.visibility = View.VISIBLE
        }
    }

    override fun onBackPressed() {
        hideAppDrawer(false)
    }

    companion object {
        var apps: MutableList<AppInfo>? = null
        var adapter: ArrayAdapter<AppInfo>? = null
    }
}
