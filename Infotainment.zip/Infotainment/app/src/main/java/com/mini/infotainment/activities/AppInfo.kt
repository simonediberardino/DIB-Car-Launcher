package com.mini.infotainment.activities

import android.graphics.drawable.Drawable

class AppInfo {
    var label: CharSequence? = null
    var name: CharSequence? = null
    var icon: Drawable? = null
}
